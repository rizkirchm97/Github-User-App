# Github-User-App

This is a Dicoding Final Project that creating Github User App.
This application is expected to be able to effectively search for a Github user and 
this application user can see the details of the Github user being searched for. This application 
is very simple and still under development but hopefully this application will help you.
